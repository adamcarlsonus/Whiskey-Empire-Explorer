"use strict";
(() => {
  // src/domain/types.ts
  var DEFAULT_VIEW_CRITERIA = Object.freeze({
    query: "",
    distillery: null,
    sort: "source"
  });

  // src/domain/price-parser.ts
  var AMOUNT_PATTERN = /\$?\s*(\d{1,3}(?:,\d{3})*|\d+)(?:\.(\d{1,2}))?/g;
  function containsUsdAmount(value) {
    const text = value.trim();
    if (!text || /(?:proof|abv|%|€|£|¥)/i.test(text)) return false;
    return [...text.matchAll(AMOUNT_PATTERN)].some((match) => match[1] !== void 0);
  }
  function parsePrice(value) {
    const displayPrice = value.trim().replace(/\s+/g, " ");
    if (!containsUsdAmount(displayPrice)) return { displayPrice, sortablePriceCents: null };
    const matches = [...displayPrice.matchAll(AMOUNT_PATTERN)];
    if (matches.length !== 1) return { displayPrice, sortablePriceCents: null };
    if (/\d\s*(?:-|–|—|to)\s*\$?\s*\d/i.test(displayPrice)) {
      return { displayPrice, sortablePriceCents: null };
    }
    const match = matches[0];
    const wholeText = match?.[1];
    if (!wholeText) return { displayPrice, sortablePriceCents: null };
    const whole = Number(wholeText.replaceAll(",", ""));
    const decimal = (match[2] ?? "").padEnd(2, "0").slice(0, 2);
    const cents = whole * 100 + Number(decimal || "0");
    if (!Number.isSafeInteger(cents)) return { displayPrice, sortablePriceCents: null };
    return { displayPrice, sortablePriceCents: cents };
  }

  // src/domain/normalize.ts
  function normalizeText(value) {
    return value.trim().replace(/\s+/g, " ").toLocaleLowerCase("en-US");
  }
  function display(value) {
    const normalized = value?.trim().replace(/\s+/g, " ") ?? "";
    return normalized || null;
  }
  function withoutSourceCode(value) {
    return display(value?.replace(/(^|\s)#[a-z0-9]{2,5}\b/gi, "$1"));
  }
  function stableId(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index += 1) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return `w-${(hash >>> 0).toString(36)}`;
  }
  function normalizeRecord(raw, sourceOrder = raw.sourceRowIndex) {
    const type = withoutSourceCode(raw.rawType);
    let name = withoutSourceCode(raw.rawName);
    if (name && type && normalizeText(name).endsWith(normalizeText(type))) name = display(name.slice(0, -type.length));
    if (!name) return { ok: false, reason: "MISSING_NAME" };
    const rawPrice = display(raw.rawPrice);
    if (!rawPrice || !containsUsdAmount(rawPrice)) return { ok: false, reason: "MISSING_PRICE" };
    const price = parsePrice(rawPrice);
    const category = display(raw.rawCategory);
    const normalizedName = normalizeText(name);
    const normalizedCategory = category ? normalizeText(category) : null;
    const sourceHref = display(raw.sourceHref);
    const identity = [normalizedName, price.displayPrice, normalizedCategory ?? "", raw.sourcePageUrl, raw.sourceRowIndex].join("|");
    return {
      ok: true,
      entry: {
        id: stableId(identity),
        sourceOrder,
        name,
        normalizedName,
        displayPrice: price.displayPrice,
        sortablePriceCents: price.sortablePriceCents,
        category,
        normalizedCategory,
        distillery: display(raw.rawDistillery),
        type,
        region: display(raw.rawRegion),
        proof: display(raw.rawProof),
        notes: display(raw.rawNotes),
        searchText: normalizeText(raw.allVisibleText.replace(/(^|\s)#[a-z0-9]{2,5}\b/gi, "$1")),
        source: { pageUrl: raw.sourcePageUrl, rowIndex: raw.sourceRowIndex, sourceHref }
      }
    };
  }
  function normalizeRecords(records) {
    const entries = [];
    let skipped = 0;
    records.forEach((raw, index) => {
      const result = normalizeRecord(raw, index);
      if (!result.ok) {
        skipped += 1;
        return;
      }
      entries.push(result.entry);
    });
    return { entries, skipped };
  }

  // src/domain/select-entries.ts
  function resetCriteria() {
    return { ...DEFAULT_VIEW_CRITERIA };
  }
  function compareName(a, b) {
    return a.normalizedName.localeCompare(b.normalizedName, "en-US") || a.sourceOrder - b.sourceOrder;
  }
  function comparePrice(a, b, sort) {
    const aPrice = a.sortablePriceCents;
    const bPrice = b.sortablePriceCents;
    if (aPrice === null && bPrice === null) return compareName(a, b);
    if (aPrice === null) return 1;
    if (bPrice === null) return -1;
    const delta = sort === "price-desc" ? bPrice - aPrice : aPrice - bPrice;
    return delta || compareName(a, b);
  }
  function selectEntries(allEntries, criteria) {
    const query = normalizeText(criteria.query);
    const distillery = criteria.distillery ? normalizeText(criteria.distillery) : null;
    const entries = allEntries.filter((entry) => {
      if (distillery && !normalizeText(entry.distillery ?? "").includes(distillery)) return false;
      return !query || entry.searchText.includes(query);
    });
    if (criteria.sort === "source") entries.sort((a, b) => a.sourceOrder - b.sourceOrder);
    else if (criteria.sort === "name-asc") entries.sort(compareName);
    else entries.sort((a, b) => comparePrice(a, b, criteria.sort));
    return { entries, total: entries.length };
  }

  // src/shared/messages.ts
  function isExtensionRequest(value) {
    if (!value || typeof value !== "object" || !("type" in value)) return false;
    return ["START_SCAN", "GET_STATUS", "CANCEL_SCAN"].includes(String(value.type));
  }

  // src/shared/target.ts
  var SUPPORTED_ORIGIN = "https://thewestsideblono.com";
  var SUPPORTED_PATH = "/drink/drink-menu/";
  var SUPPORTED_URL = `${SUPPORTED_ORIGIN}${SUPPORTED_PATH}`;
  var PAGINATION_ORIGIN = "https://business.untappd.com";
  var MAX_PAGES = 20;
  var MAX_ENTRIES = 2e3;
  var PAGINATION_PATH = /^\/locations\/\d+\/themes\/\d+\/items\/?$/;
  function canonicalizePaginationUrl(url) {
    if (url.protocol !== "https:" || url.origin !== PAGINATION_ORIGIN || !PAGINATION_PATH.test(url.pathname)) return null;
    const page = url.searchParams.get("page");
    const sectionId = url.searchParams.get("section_id");
    if (!page || !/^\d+$/.test(page) || Number(page) < 1 || Number(page) > MAX_PAGES) return null;
    if (!sectionId || !/^\d+$/.test(sectionId)) return null;
    url.search = "";
    url.searchParams.set("page", page);
    url.searchParams.set("section_id", sectionId);
    return url;
  }
  function canonicalizeUrl(value, base = SUPPORTED_URL) {
    try {
      const url = new URL(value, base);
      url.hash = "";
      if (url.origin === PAGINATION_ORIGIN) return canonicalizePaginationUrl(url);
      if (url.protocol !== "https:" || url.origin !== SUPPORTED_ORIGIN) return null;
      const normalizedPath = url.pathname.endsWith("/") ? url.pathname : `${url.pathname}/`;
      if (normalizedPath !== SUPPORTED_PATH) return null;
      url.pathname = SUPPORTED_PATH;
      return url;
    } catch {
      return null;
    }
  }
  function isPaginationUrl(value) {
    try {
      const supplied = new URL(value);
      return supplied.origin === PAGINATION_ORIGIN && canonicalizePaginationUrl(supplied) !== null;
    } catch {
      return false;
    }
  }
  function isSupportedUrl(value) {
    const url = canonicalizeUrl(value);
    if (!url) return false;
    const supplied = new URL(value);
    return supplied.origin === SUPPORTED_ORIGIN && (supplied.pathname === SUPPORTED_PATH || supplied.pathname === SUPPORTED_PATH.slice(0, -1));
  }

  // src/content/target-adapter.ts
  var ROW_SELECTORS = ["[data-whiskey-entry]", ".whiskey-entry", ".menu-item", "tr"];
  var NAME_SELECTORS = ["[data-name]", ".whiskey-name", ".item-name", "th", "h3", "h4", "strong"];
  var PRICE_SELECTORS = ["[data-price]", ".whiskey-price", ".price", ".item-price", "td:last-child"];
  var TAB_SELECTORS = '[role="tab"], .et_pb_tabs_controls li, [data-tab], .tablinks, .tab-anchor[data-tab-id]';
  function textFrom(root, selectors) {
    for (const selector of selectors) {
      const value = root.querySelector(selector)?.textContent?.trim();
      if (value) return value;
    }
    return "";
  }
  function isWhiskeyTab(element) {
    return /whiskey\s+empire/i.test(element.textContent ?? "");
  }
  function isSelectedTab(element) {
    const selected = element.getAttribute("aria-selected");
    return selected === "true" || /(?:^|\s)(?:active|selected|et_pb_tab_active)(?:\s|$)/i.test(element.className);
  }
  function findTabRoot(document2) {
    const explicit = document2.querySelector("[data-whiskey-empire-list]");
    const tabs = [...document2.querySelectorAll(TAB_SELECTORS)];
    const whiskeyTabs = tabs.filter((tab) => isWhiskeyTab(tab));
    const whiskeyTab = whiskeyTabs.find((tab) => isSelectedTab(tab) && /whiskey\s+empire/i.test(tab.closest(".ut-menu")?.querySelector(".menu-title")?.textContent ?? "")) ?? whiskeyTabs.find((tab) => isSelectedTab(tab)) ?? whiskeyTabs[0];
    if (whiskeyTab && !isSelectedTab(whiskeyTab)) return null;
    if (explicit) return explicit;
    if (!whiskeyTab) return null;
    const target = whiskeyTab.getAttribute("aria-controls") ?? whiskeyTab.getAttribute("data-target") ?? whiskeyTab.getAttribute("href")?.replace(/^#/, "");
    if (target) {
      const controlled = document2.getElementById(target.replace(/^#/, ""));
      if (controlled) return controlled;
    }
    const untappdMenu = whiskeyTab.closest(".ut-menu");
    const untappdPanel = untappdMenu ? [...untappdMenu.querySelectorAll(".tab-content")].find((panel) => /whiskey\s+empire/i.test(panel.querySelector(".menu-title")?.textContent ?? "")) ?? null : null;
    return untappdPanel ?? whiskeyTab.closest(".tabs, .et_pb_tabs")?.querySelector('.et_pb_tab_active, [role="tabpanel"]') ?? null;
  }
  async function activateWhiskeyTab(document2, timeoutMs = 5e3) {
    if (!isSupportedUrl(document2.location?.href ?? "") || locateActiveList(document2).ok) return locateActiveList(document2).ok;
    const tab = [...document2.querySelectorAll(TAB_SELECTORS)].find((candidate) => isWhiskeyTab(candidate));
    if (!tab) return false;
    if (isSelectedTab(tab)) return true;
    tab.click();
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (locateActiveList(document2).ok) return true;
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    return locateActiveList(document2).ok;
  }
  function locateActiveList(document2, pageUrl = document2.location?.href ?? "") {
    if (!isSupportedUrl(pageUrl)) return { ok: false, code: "WRONG_URL" };
    const root = findTabRoot(document2);
    if (!root) return { ok: false, code: "TAB_NOT_ACTIVE" };
    const hasRows = ROW_SELECTORS.some((selector) => root.querySelector(selector));
    if (!hasRows) return { ok: false, code: "UNSUPPORTED_STRUCTURE" };
    const canonicalPageUrl = canonicalizeUrl(pageUrl);
    if (!canonicalPageUrl) return { ok: false, code: "WRONG_URL" };
    return { ok: true, root, canonicalPageUrl };
  }
  function field(row, selector) {
    const value = row.querySelector(selector)?.textContent?.trim();
    return value || void 0;
  }
  function categoryFor(row) {
    const own = row.getAttribute("data-category") ?? field(row, "[data-category], .whiskey-category, .category");
    if (own) return own.trim();
    const section = row.closest("[data-category]");
    if (section) return section.getAttribute("data-category")?.trim() || section.querySelector(":scope > h2, :scope > h3")?.textContent?.trim() || void 0;
    return row.closest(".section")?.querySelector(".section-name")?.textContent?.trim() || void 0;
  }
  function extractPage(document2, pageUrl) {
    const located = isPaginationUrl(pageUrl) ? (() => {
      const canonicalPageUrl = canonicalizeUrl(pageUrl);
      const root = document2.body;
      return canonicalPageUrl && root && root.querySelector(ROW_SELECTORS.join(",")) ? { ok: true, root, canonicalPageUrl } : { ok: false, code: "UNSUPPORTED_STRUCTURE" };
    })() : locateActiveList(document2, pageUrl);
    if (!located.ok) throw Object.assign(new Error(located.code), { code: located.code });
    const rows = [...located.root.querySelectorAll(ROW_SELECTORS.join(","))].filter(
      (row, index, all) => !all.some((other, otherIndex) => otherIndex !== index && other.contains(row) && ROW_SELECTORS.some((selector) => other.matches(selector)))
    );
    const records = [];
    let skippedCandidates = 0;
    rows.forEach((row, sourceRowIndex) => {
      const rawName = textFrom(row, NAME_SELECTORS);
      const rawPrice = textFrom(row, PRICE_SELECTORS);
      if (!rawName || !rawPrice) {
        skippedCandidates += 1;
        return;
      }
      const sourceHref = row.querySelector("a[href]")?.href;
      records.push({
        rawName,
        rawPrice,
        rawCategory: categoryFor(row),
        rawDistillery: field(row, ".item-producer, [data-brand], .whiskey-brand, .brand, .brewery"),
        rawType: field(row, "[data-type], .whiskey-type, .item-category, .item-style, .type"),
        rawRegion: field(row, "[data-region], .whiskey-region, .region, .item-brewery-location"),
        rawProof: field(row, ".item-abv, [data-proof], .whiskey-proof, .proof"),
        rawNotes: field(row, "[data-notes], .whiskey-notes, .description, p"),
        allVisibleText: row.textContent?.trim().replace(/\s+/g, " ") ?? "",
        sourcePageUrl: located.canonicalPageUrl.href,
        sourceRowIndex,
        ...sourceHref ? { sourceHref } : {}
      });
    });
    const paginationUrls = [...located.root.querySelectorAll('nav a[href], [aria-label*="pagination" i] a[href], .pagination a[href]')].map((anchor) => canonicalizeUrl(anchor.href, located.canonicalPageUrl.href)).filter((url) => url !== null);
    const totalMatch = (located.root.textContent ?? "").match(/Displaying items\s+\d+\s*-\s*\d+\s+of\s+([\d,]+)\s+in total/i);
    const advertisedTotal = totalMatch?.[1] ? Number(totalMatch[1].replaceAll(",", "")) : null;
    return { records, candidateCount: rows.length, skippedCandidates, paginationUrls, advertisedTotal };
  }

  // src/content/pagination.ts
  var PAGE_TIMEOUT_MS = 15e3;
  async function fetchPage(fetchImpl, url, parentSignal) {
    const controller = new AbortController();
    const abort = () => controller.abort(parentSignal.reason);
    parentSignal.addEventListener("abort", abort, { once: true });
    const timeout = setTimeout(() => controller.abort(new DOMException("Page request timed out", "TimeoutError")), PAGE_TIMEOUT_MS);
    try {
      return await fetchImpl(url, { credentials: "same-origin", signal: controller.signal });
    } finally {
      clearTimeout(timeout);
      parentSignal.removeEventListener("abort", abort);
    }
  }
  function scanError(code, message) {
    return Object.assign(new Error(message), { code });
  }
  async function traversePagination(options) {
    const fetchImpl = options.fetchImpl ?? fetch;
    const extractor = options.extract ?? extractPage;
    const initial = canonicalizeUrl(options.initialUrl);
    if (!initial) throw scanError("WRONG_URL", "Open the supported Westside drink menu first.");
    const queue = [initial];
    const seen = /* @__PURE__ */ new Set();
    const pages = [];
    const rawRecords = [];
    let skippedCandidates = 0;
    let warning = null;
    let advertisedTotal = null;
    while (queue.length && pages.length < MAX_PAGES && rawRecords.length < MAX_ENTRIES) {
      if (options.signal.aborted) throw new DOMException("Scan cancelled", "AbortError");
      const current = queue.shift();
      if (!current || seen.has(current.href)) continue;
      seen.add(current.href);
      const page = { url: current.href, state: "loading", entryCount: 0, skippedCandidates: 0, errorCode: null };
      pages.push(page);
      try {
        let document2;
        if (pages.length === 1) document2 = options.initialDocument;
        else {
          const response = await fetchPage(fetchImpl, current.href, options.signal);
          if (!response.ok) throw scanError("REQUEST_FAILED", `Page request failed with ${response.status}.`);
          document2 = new DOMParser().parseFromString(await response.text(), "text/html");
        }
        const extraction = extractor(document2, current.href);
        if (extraction.advertisedTotal !== null) advertisedTotal = Math.max(advertisedTotal ?? 0, extraction.advertisedTotal);
        const remaining = Math.max(0, MAX_ENTRIES - rawRecords.length);
        rawRecords.push(...extraction.records.slice(0, remaining));
        skippedCandidates += extraction.skippedCandidates;
        page.state = "parsed";
        page.entryCount = Math.min(extraction.records.length, remaining);
        page.skippedCandidates = extraction.skippedCandidates;
        for (const discovered of extraction.paginationUrls) {
          if (!seen.has(discovered.href) && !queue.some((url) => url.href === discovered.href)) queue.push(discovered);
        }
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") throw error;
        const code = typeof error === "object" && error && "code" in error ? String(error.code) : "PARSE_FAILED";
        page.state = "failed";
        page.errorCode = code;
        if (rawRecords.length === 0) throw scanError(code, error instanceof Error ? error.message : "Unable to read the whiskey list.");
        warning = { code: "PARTIAL_RESULTS", message: "A later page could not be read. Results are incomplete." };
        options.onProgress?.({ pages: [...pages], records: rawRecords.length, skippedCandidates });
        break;
      }
      options.onProgress?.({ pages: [...pages], records: rawRecords.length, skippedCandidates });
    }
    if (!warning && advertisedTotal !== null && rawRecords.length < advertisedTotal) {
      warning = { code: "PARTIAL_RESULTS", message: `Collected ${rawRecords.length} of ${advertisedTotal} advertised entries. Results are incomplete.` };
    } else if (!warning && queue.length) {
      warning = pages.length >= MAX_PAGES ? { code: "PAGE_LIMIT_REACHED", message: `Stopped safely after ${MAX_PAGES} pages. Results are partial.` } : { code: "ENTRY_LIMIT_REACHED", message: `Stopped safely after ${MAX_ENTRIES} entries. Results are partial.` };
    } else if (!warning && skippedCandidates > 0) {
      warning = { code: "SKIPPED_CANDIDATES", message: `${skippedCandidates} candidate rows lacked a recognizable name or displayed price.` };
    }
    return { pages, rawRecords, records: rawRecords.length, skippedCandidates, warning };
  }

  // src/content/scanner.ts
  function freshSession() {
    return {
      sessionId: crypto.randomUUID(),
      status: "idle",
      pages: [],
      entries: [],
      skippedCandidates: 0,
      startedAt: null,
      completedAt: null,
      warning: null,
      error: null
    };
  }
  function publicMessage(code) {
    const messages = {
      WRONG_URL: "Open the supported Westside drink menu first.",
      TAB_NOT_ACTIVE: "The Whiskey Empire collection could not be opened automatically.",
      UNSUPPORTED_STRUCTURE: "This version of the whiskey list is not supported.",
      REQUEST_FAILED: "A whiskey-list page could not be requested.",
      PARSE_FAILED: "A whiskey-list page could not be read.",
      NO_VALID_ENTRIES: "No entries with both a name and displayed price were found.",
      NOT_INJECTED: "The extension panel is not available in this tab."
    };
    return messages[code];
  }
  var Scanner = class {
    session = freshSession();
    controller = null;
    get current() {
      return this.session;
    }
    snapshot() {
      const processedEntryCount = this.session.pages.reduce((sum, page) => sum + page.entryCount, 0);
      return {
        status: this.session.status,
        pagesDiscovered: this.session.pages.length,
        pagesProcessed: this.session.pages.filter((page) => page.state === "parsed" || page.state === "failed").length,
        entriesCollected: this.session.entries.length || processedEntryCount,
        skippedCandidates: this.session.skippedCandidates,
        warning: this.session.warning,
        error: this.session.error
      };
    }
    async start(document2, listener) {
      if (["validating", "scanning", "normalizing", "ready"].includes(this.session.status)) {
        listener(this.session);
        return this.session;
      }
      this.controller?.abort();
      this.controller = new AbortController();
      this.session = freshSession();
      this.session.status = "validating";
      this.session.startedAt = performance.now();
      listener(this.session);
      try {
        this.session.status = "scanning";
        listener(this.session);
        const traversal = await traversePagination({
          initialDocument: document2,
          initialUrl: document2.location.href,
          signal: this.controller.signal,
          onProgress: (progress) => {
            this.session.pages = progress.pages;
            this.session.skippedCandidates = progress.skippedCandidates;
            listener(this.session);
          }
        });
        this.session.status = "normalizing";
        listener(this.session);
        const normalized = normalizeRecords(traversal.rawRecords);
        this.session.entries = normalized.entries;
        this.session.skippedCandidates = traversal.skippedCandidates + normalized.skipped;
        this.session.warning = traversal.warning;
        if (!this.session.entries.length) throw Object.assign(new Error(publicMessage("NO_VALID_ENTRIES")), { code: "NO_VALID_ENTRIES" });
        this.session.status = traversal.warning?.code === "PARTIAL_RESULTS" || traversal.warning?.code.endsWith("LIMIT_REACHED") ? "partial" : "ready";
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") this.session.status = "cancelled";
        else {
          const code = typeof error === "object" && error && "code" in error ? String(error.code) : "PARSE_FAILED";
          this.session.status = ["WRONG_URL", "TAB_NOT_ACTIVE", "UNSUPPORTED_STRUCTURE", "NO_VALID_ENTRIES"].includes(code) ? "unsupported" : "failed";
          this.session.error = { code, message: publicMessage(code) };
        }
      }
      this.session.completedAt = performance.now();
      listener(this.session);
      return this.session;
    }
    cancel(listener) {
      this.controller?.abort();
      if (["validating", "scanning", "normalizing"].includes(this.session.status)) this.session.status = "cancelled";
      this.session.completedAt = performance.now();
      listener?.(this.session);
    }
    reset() {
      this.controller?.abort();
      this.controller = null;
      this.session = freshSession();
    }
    continuePartial(listener) {
      if (this.session.status === "partial") {
        this.session.status = "ready";
        listener(this.session);
      }
    }
  };

  // src/ui/panel-styles.ts
  var panelStyles = String.raw`
:host {
  --wew-bg: #000;
  --wew-surface: #2f2f2f;
  --wew-surface-hover: #424242;
  --wew-border: #424242;
  --wew-text: #f2f2f2;
  --wew-muted: #b4b4b4;
  --wew-focus: #8ab4f8;
  color-scheme: dark;
  display: block;
  font: 16px/1.5 ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
  margin: 1rem 0;
}
* { box-sizing: border-box; }
.panel { background: var(--wew-bg); border: 1px solid var(--wew-border); border-radius: 18px; box-shadow: 0 18px 50px rgba(0, 0, 0, .35); color: var(--wew-text); padding: 1.25rem; }
.header, .controls, .actions { align-items: end; display: flex; flex-wrap: wrap; gap: .75rem; justify-content: space-between; }
h2 { font-size: 1.35rem; letter-spacing: -.025em; margin: 0; }
label { display: grid; font-weight: 600; gap: .35rem; }
.field-label { font-weight: 600; }
input, select, button, a { font: inherit; }
input, select { background: var(--wew-surface); border: 1px solid var(--wew-border); border-radius: 10px; box-shadow: none; color: var(--wew-text); min-height: 2.75rem; padding: .55rem .75rem; transition: background-color .15s ease, border-color .15s ease; }
input::placeholder { color: var(--wew-muted); opacity: 1; }
input:hover, select:hover { background: var(--wew-surface-hover); }
select { appearance: none; background-image: linear-gradient(45deg, transparent 50%, var(--wew-muted) 50%), linear-gradient(135deg, var(--wew-muted) 50%, transparent 50%); background-position: calc(100% - 15px) 50%, calc(100% - 10px) 50%; background-repeat: no-repeat; background-size: 5px 5px, 5px 5px; cursor: pointer; padding-right: 2.35rem; }
.sort-field, .distillery-field { display: grid; gap: .35rem; min-width: 12rem; position: relative; }
.combobox-shell { align-items: center; display: flex; position: relative; }
.distillery-control { padding-right: 2.5rem; width: 100%; }
.combobox-shell .chevron { pointer-events: none; position: absolute; right: .9rem; }
.distillery-control[aria-expanded="true"] + .chevron { transform: rotate(225deg) translate(-.1rem, -.1rem); }
.sort-trigger { align-items: center; background: var(--wew-surface); border: 1px solid var(--wew-border); border-radius: 10px; box-shadow: none; color: var(--wew-text); display: flex; font-weight: 500; justify-content: space-between; min-width: 12rem; padding: .55rem .8rem; text-align: left; }
.sort-trigger:hover, .sort-trigger[aria-expanded="true"] { background: var(--wew-surface-hover); }
.chevron { border-bottom: 2px solid currentColor; border-right: 2px solid currentColor; height: .5rem; margin-left: 1rem; transform: rotate(45deg) translateY(-.15rem); transition: transform .15s ease; width: .5rem; }
.sort-trigger[aria-expanded="true"] .chevron { transform: rotate(225deg) translate(-.1rem, -.1rem); }
.sort-list { background: var(--wew-surface); border: 1px solid var(--wew-border); border-radius: 14px; box-shadow: 0 18px 45px rgba(0, 0, 0, .55); display: grid; gap: .2rem; left: 0; min-width: 100%; padding: .4rem; position: absolute; top: calc(100% + .4rem); z-index: 20; }
.sort-option { background: transparent; border: 0; border-radius: 9px; color: var(--wew-text); display: grid; font-weight: 500; gap: .55rem; grid-template-columns: 1rem 1fr; justify-items: start; min-height: 2.4rem; padding: .5rem .65rem; text-align: left; white-space: nowrap; }
.sort-option::before { content: ""; }
.sort-option[aria-selected="true"] { background: var(--wew-surface-hover); }
.sort-option[aria-selected="true"]::before { content: "✓"; font-weight: 800; }
.sort-option:hover, .sort-option:focus-visible { background: #525252; }
.native-sort { clip: rect(0 0 0 0); clip-path: inset(50%); height: 1px; overflow: hidden; position: absolute; white-space: nowrap; width: 1px; }
button, .original-link { border-radius: 10px; min-height: 2.5rem; padding: .5rem .75rem; }
button { background: var(--wew-text); border: 1px solid var(--wew-text); color: #0d0d0d; cursor: pointer; font-weight: 600; }
button:hover { background: #d9d9d9; border-color: #d9d9d9; }
.secondary { background: var(--wew-surface); border-color: var(--wew-border); color: var(--wew-text); }
.secondary:hover { background: var(--wew-surface-hover); border-color: var(--wew-surface-hover); }
.original-link { color: var(--wew-text); display: inline-flex; align-items: center; }
.nav-action { align-items: center; background: transparent; border: 1px solid transparent; color: var(--wew-text); display: inline-flex; font-weight: 500; gap: .65rem; justify-content: flex-start; padding: .5rem .65rem; text-decoration: none; width: auto; }
.nav-action:hover { background: var(--wew-surface); border-color: transparent; color: var(--wew-text); }
.nav-action svg { fill: none; flex: 0 0 auto; height: 1.4rem; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.8; width: 1.4rem; }
:focus-visible { outline: 3px solid var(--wew-focus); outline-offset: 2px; }
h2:focus-visible { outline: none; }
.status { color: var(--wew-muted); margin: .85rem 0; }
.warning, .error { background: #2b2118; border-left: 4px solid #f2a33c; border-radius: 6px; font-weight: 600; padding: .6rem .8rem; }
.error { background: #2d1719; border-color: #ff6b72; }
.results-wrap { max-width: 100%; }
table { border-collapse: collapse; width: 100%; }
.menu-list thead { clip: rect(0 0 0 0); clip-path: inset(50%); height: 1px; overflow: hidden; position: absolute; white-space: nowrap; width: 1px; }
.menu-list tbody { display: block; }
.menu-list tr { border-bottom: 1px solid var(--wew-border); display: grid; gap: .25rem .7rem; grid-template-columns: auto 1fr auto; padding: 1.2rem .25rem; }
.menu-list td { border: 0; padding: 0; text-align: left; vertical-align: top; }
.menu-list td[data-label="Name"] { font-size: 1.08rem; font-weight: 750; grid-column: 1 / 3; grid-row: 1; letter-spacing: .015em; min-width: 0; text-transform: uppercase; }
.item-type { color: var(--wew-muted); font-style: italic; font-weight: 450; }
.menu-list td[data-label="Distillery"], .menu-list td[data-label="Proof"] { color: var(--wew-muted); grid-row: 2; }
.menu-list td[data-label="Distillery"]::before { content: "• "; margin-right: .35rem; }
.menu-list td[data-label="Notes"] { color: var(--wew-muted); grid-column: 1 / -1; grid-row: 3; }
.menu-list td[data-label="Search"] { align-self: start; grid-column: 3; grid-row: 1; justify-self: end; }
.product-search { align-items: center; border-radius: 9px; color: var(--wew-text); display: inline-flex; font-weight: 500; gap: .55rem; padding: .35rem .5rem; text-decoration: none; }
.product-search:hover { background: var(--wew-surface); }
.product-search svg { fill: none; height: 1.2rem; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.8; width: 1.2rem; }
.menu-list td[data-label="Price"] { align-items: center; display: grid; font-weight: 650; gap: .55rem; grid-column: 1 / -1; grid-row: 4; grid-template-columns: auto 1fr auto; margin-top: .6rem; }
.price-leader { border-bottom: 2px dotted var(--wew-border); min-width: 2rem; }
.price-value { white-space: nowrap; }
th button { background: transparent; border-color: transparent; color: var(--wew-text); padding: .25rem; }
.muted { color: var(--wew-muted); }
[hidden] { display: none !important; }
@media (max-width: 700px) {
  .menu-list tr { grid-template-columns: auto 1fr; }
  .menu-list td[data-label="Name"] { grid-column: 1; }
  .menu-list td[data-label="Search"] { grid-column: 2; }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { scroll-behavior: auto !important; transition: none !important; }
}
`;

  // src/ui/panel.ts
  var PANEL_HOST_ID = "whiskey-empire-west-panel";
  function focusPanel(view) {
    view.heading.focus();
  }
  function createPanel(before, actions) {
    const existing = document.getElementById(PANEL_HOST_ID);
    if (existing?.shadowRoot) {
      const heading = existing.shadowRoot.querySelector("#wew-heading");
      heading?.focus();
      throw Object.assign(new Error("Panel already exists"), { code: "PANEL_EXISTS" });
    }
    const host = document.createElement("section");
    host.id = PANEL_HOST_ID;
    host.setAttribute("aria-label", "Enhanced whiskey list");
    before.parentElement?.insertBefore(host, before);
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `<style>${panelStyles}</style>
    <section class="panel" aria-labelledby="wew-heading">
      <div class="header"><h2 id="wew-heading" tabindex="-1">Whiskey Empire Explorer</h2>
        <div class="actions">
          <a class="original-link nav-action" href="#" id="wew-original"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg><span>Original list</span></a>
          <button class="secondary nav-action" id="wew-close" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg><span>Close</span></button>
        </div>
      </div>
      <p id="wew-status" class="status" role="status" aria-live="polite">Preparing scan\u2026</p>
      <p id="wew-warning" class="warning" hidden></p>
      <div id="wew-controls" class="controls" hidden>
        <label>Search all visible text<input id="wew-query" type="search" autocomplete="off"></label>
        <div class="distillery-field" id="wew-distillery-field" hidden><label class="field-label" id="wew-distillery-label" for="wew-distillery">Distillery</label>
          <div class="combobox-shell"><input class="distillery-control" id="wew-distillery" type="search" autocomplete="off" placeholder="All distilleries" role="combobox" aria-autocomplete="list" aria-haspopup="listbox" aria-expanded="false" aria-controls="wew-distillery-list" aria-labelledby="wew-distillery-label"><span class="chevron" aria-hidden="true"></span></div>
          <div class="sort-list distillery-list" id="wew-distillery-list" role="listbox" aria-labelledby="wew-distillery-label" hidden></div>
        </div>
        <div class="sort-field" id="wew-sort-field"><span class="field-label" id="wew-sort-label">Sort</span>
          <button class="sort-trigger" id="wew-sort-button" type="button" aria-haspopup="listbox" aria-expanded="false" aria-controls="wew-sort-list" aria-labelledby="wew-sort-label wew-sort-value"><span id="wew-sort-value">Original order</span><span class="chevron" aria-hidden="true"></span></button>
          <div class="sort-list" id="wew-sort-list" role="listbox" aria-labelledby="wew-sort-label" hidden>
            <button class="sort-option" type="button" role="option" data-value="source" aria-selected="true">Original order</button>
            <button class="sort-option" type="button" role="option" data-value="name-asc" aria-selected="false">Name A\u2013Z</button>
            <button class="sort-option" type="button" role="option" data-value="price-asc" aria-selected="false">Price low\u2013high</button>
            <button class="sort-option" type="button" role="option" data-value="price-desc" aria-selected="false">Price high\u2013low</button>
          </div>
          <select class="native-sort" id="wew-sort" tabindex="-1" aria-hidden="true"><option value="source">Original order</option><option value="name-asc">Name A\u2013Z</option><option value="price-asc">Price low\u2013high</option><option value="price-desc">Price high\u2013low</option></select>
        </div>
        <button class="secondary nav-action" id="wew-reset" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg><span>Reset</span></button>
      </div>
      <div class="actions"><button id="wew-cancel" type="button">Cancel scan</button><button id="wew-retry" type="button" hidden>Retry</button><button id="wew-continue" type="button" hidden>Continue with partial results</button></div>
      <p id="wew-count" aria-live="polite"></p>
      <div class="results-wrap"><table class="menu-list" hidden id="wew-table"><thead><tr><th id="wew-name-head" scope="col">Name</th><th scope="col">Proof</th><th scope="col">Distillery</th><th scope="col">Notes</th><th scope="col">Search</th><th id="wew-price-head" scope="col">Price</th></tr></thead><tbody id="wew-body"></tbody></table></div>
    </section>`;
    const required = (selector) => {
      const element = shadow.querySelector(selector);
      if (!element) throw new Error(`Missing panel element: ${selector}`);
      return element;
    };
    const view = {
      host,
      shadow,
      heading: required("#wew-heading"),
      status: required("#wew-status"),
      warning: required("#wew-warning"),
      controls: required("#wew-controls"),
      query: required("#wew-query"),
      distilleryField: required("#wew-distillery-field"),
      distillery: required("#wew-distillery"),
      distilleryList: required("#wew-distillery-list"),
      sort: required("#wew-sort"),
      sortField: required("#wew-sort-field"),
      sortButton: required("#wew-sort-button"),
      sortValue: required("#wew-sort-value"),
      sortList: required("#wew-sort-list"),
      reset: required("#wew-reset"),
      cancel: required("#wew-cancel"),
      retry: required("#wew-retry"),
      continueButton: required("#wew-continue"),
      close: required("#wew-close"),
      count: required("#wew-count"),
      body: required("#wew-body"),
      nameHeader: required("#wew-name-head"),
      priceHeader: required("#wew-price-head")
    };
    required("#wew-original").href = window.location.href;
    const emitCriteria = () => actions.onCriteria({ query: view.query.value, distillery: view.distillery.value || null, sort: view.sort.value });
    const distilleryOptions = () => [...view.distilleryList.querySelectorAll(".distillery-option")];
    const filteredDistilleryOptions = () => {
      const query = view.distillery.value.trim().toLocaleLowerCase("en-US");
      const options = distilleryOptions();
      for (const option of options) {
        const value = option.dataset.value ?? "";
        option.hidden = Boolean(query && !value.toLocaleLowerCase("en-US").includes(query));
        option.setAttribute("aria-selected", String(Boolean(query) && value.toLocaleLowerCase("en-US") === query));
      }
      return options.filter((option) => !option.hidden);
    };
    const closeDistilleries = (restoreFocus = false) => {
      view.distilleryList.hidden = true;
      view.distillery.setAttribute("aria-expanded", "false");
      if (restoreFocus) view.distillery.focus();
    };
    const openDistilleries = () => {
      if (!filteredDistilleryOptions().length) return closeDistilleries();
      view.distilleryList.hidden = false;
      view.distillery.setAttribute("aria-expanded", "true");
    };
    const chooseDistillery = (option) => {
      view.distillery.value = option.dataset.value ?? "";
      emitCriteria();
      view.distillery.focus();
      closeDistilleries();
    };
    const sortOptions = () => [...view.sortList.querySelectorAll(".sort-option")];
    const syncSort = () => {
      const selected = sortOptions().find((option) => option.dataset.value === view.sort.value) ?? sortOptions()[0];
      if (!selected) return;
      view.sortValue.textContent = selected.textContent;
      for (const option of sortOptions()) option.setAttribute("aria-selected", String(option === selected));
    };
    const closeSort = (restoreFocus = false) => {
      view.sortList.hidden = true;
      view.sortButton.setAttribute("aria-expanded", "false");
      if (restoreFocus) view.sortButton.focus();
    };
    const openSort = () => {
      view.sortList.hidden = false;
      view.sortButton.setAttribute("aria-expanded", "true");
      (sortOptions().find((option) => option.getAttribute("aria-selected") === "true") ?? sortOptions()[0])?.focus();
    };
    const chooseSort = (option) => {
      view.sort.value = option.dataset.value ?? "source";
      syncSort();
      closeSort(true);
      emitCriteria();
    };
    view.query.addEventListener("input", emitCriteria);
    view.distillery.addEventListener("input", () => {
      emitCriteria();
      openDistilleries();
    });
    view.distillery.addEventListener("focus", openDistilleries);
    view.distillery.addEventListener("click", openDistilleries);
    view.distillery.addEventListener("keydown", (event) => {
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        openDistilleries();
        const options = filteredDistilleryOptions();
        options[event.key === "ArrowDown" ? 0 : options.length - 1]?.focus();
      } else if (event.key === "Escape") closeDistilleries();
    });
    view.distilleryList.addEventListener("click", (event) => {
      const option = event.target instanceof Element ? event.target.closest(".distillery-option") : null;
      if (option) chooseDistillery(option);
    });
    view.distilleryList.addEventListener("keydown", (event) => {
      const option = event.target instanceof Element ? event.target.closest(".distillery-option") : null;
      if (!option) return;
      const options = filteredDistilleryOptions();
      const index = options.indexOf(option);
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        options[(index + (event.key === "ArrowDown" ? 1 : -1) + options.length) % options.length]?.focus();
      } else if (event.key === "Home" || event.key === "End") {
        event.preventDefault();
        options[event.key === "Home" ? 0 : options.length - 1]?.focus();
      } else if (event.key === "Escape") {
        event.preventDefault();
        closeDistilleries(true);
      }
    });
    view.distilleryField.addEventListener("focusout", () => setTimeout(() => {
      if (!view.distilleryField.contains(view.shadow.activeElement)) closeDistilleries();
    }, 0));
    view.sort.addEventListener("change", () => {
      syncSort();
      emitCriteria();
    });
    view.sortButton.addEventListener("click", () => view.sortList.hidden ? openSort() : closeSort());
    view.sortButton.addEventListener("keydown", (event) => {
      if (["ArrowDown", "ArrowUp", "Enter", " "].includes(event.key)) {
        event.preventDefault();
        openSort();
      }
      if (event.key === "Escape") closeSort();
    });
    for (const option of sortOptions()) {
      option.addEventListener("click", () => chooseSort(option));
      option.addEventListener("keydown", (event) => {
        const options = sortOptions();
        const index = options.indexOf(option);
        if (event.key === "ArrowDown" || event.key === "ArrowUp") {
          event.preventDefault();
          options[(index + (event.key === "ArrowDown" ? 1 : -1) + options.length) % options.length]?.focus();
        } else if (event.key === "Home" || event.key === "End") {
          event.preventDefault();
          options[event.key === "Home" ? 0 : options.length - 1]?.focus();
        } else if (event.key === "Escape") {
          event.preventDefault();
          closeSort(true);
        }
      });
    }
    view.sortField.addEventListener("focusout", () => setTimeout(() => {
      if (!view.sortField.contains(view.shadow.activeElement)) closeSort();
    }, 0));
    view.reset.addEventListener("click", actions.onReset);
    view.cancel.addEventListener("click", actions.onCancel);
    view.retry.addEventListener("click", actions.onRetry);
    view.continueButton.addEventListener("click", actions.onContinue);
    view.close.addEventListener("click", actions.onClose);
    required("#wew-original").addEventListener("click", (event) => {
      event.preventDefault();
      before.scrollIntoView({ block: "start", behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
      (before.querySelector("h1,h2,h3,[tabindex]") ?? before).focus?.();
    });
    queueMicrotask(() => focusPanel(view));
    return view;
  }

  // src/ui/render.ts
  function cell(row, label, value) {
    const td = document.createElement("td");
    td.dataset.label = label;
    td.textContent = value;
    row.append(td);
  }
  function nameCell(row, entry) {
    const td = document.createElement("td");
    td.dataset.label = "Name";
    const name = document.createElement("span");
    name.className = "item-name";
    name.textContent = entry.name;
    td.append(name);
    if (entry.type) {
      const type = document.createElement("span");
      type.className = "item-type";
      type.textContent = entry.type;
      td.append(" ", type);
    }
    row.append(td);
  }
  function priceCell(row, entry) {
    const td = document.createElement("td");
    td.dataset.label = "Price";
    const label = document.createElement("span");
    label.className = "price-label";
    label.textContent = "Price";
    const leader = document.createElement("span");
    leader.className = "price-leader";
    leader.setAttribute("aria-hidden", "true");
    const value = document.createElement("span");
    value.className = "price-value";
    value.textContent = entry.sortablePriceCents === null ? `${entry.displayPrice} (not comparable)` : entry.displayPrice;
    td.append(label, leader, value);
    row.append(td);
  }
  function searchCell(row, entry) {
    const query = [entry.name, entry.type].filter(Boolean).join(" ");
    const td = document.createElement("td");
    td.dataset.label = "Search";
    const link = document.createElement("a");
    link.className = "product-search";
    link.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.setAttribute("aria-label", `Google Search for ${query}`);
    const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    icon.setAttribute("viewBox", "0 0 24 24");
    icon.setAttribute("aria-hidden", "true");
    const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    circle.setAttribute("cx", "11");
    circle.setAttribute("cy", "11");
    circle.setAttribute("r", "7");
    const handle = document.createElementNS("http://www.w3.org/2000/svg", "path");
    handle.setAttribute("d", "m16 16 5 5");
    const label = document.createElement("span");
    label.textContent = "Google Search";
    icon.append(circle, handle);
    link.append(icon, label);
    td.append(link);
    row.append(td);
  }
  function rowFor(entry) {
    const row = document.createElement("tr");
    row.dataset.entryId = entry.id;
    nameCell(row, entry);
    cell(row, "Proof", entry.proof ?? "\u2014");
    cell(row, "Distillery", entry.distillery ?? "\u2014");
    cell(row, "Notes", entry.notes ?? (entry.region || "\u2014"));
    searchCell(row, entry);
    priceCell(row, entry);
    return row;
  }
  function statusText(session) {
    const processed = session.pages.filter((page) => page.state === "parsed" || page.state === "failed").length;
    const collected = session.entries.length || session.pages.reduce((sum, page) => sum + page.entryCount, 0);
    if (["validating", "scanning"].includes(session.status)) return `Scanning page ${processed} of ${session.pages.length || "an unknown total"}; ${collected} entries collected; ${session.skippedCandidates} skipped.`;
    if (session.status === "normalizing") return "Normalizing collected whiskey entries\u2026";
    if (session.status === "ready") return `Scan complete: ${session.entries.length} entries.`;
    if (session.status === "partial") return `Partial scan complete: ${session.entries.length} entries.`;
    if (session.status === "cancelled") return "Scan cancelled. Temporary results were discarded.";
    return session.error?.message ?? "Ready.";
  }
  function updatePanel(view, session, criteria) {
    view.sort.value = criteria.sort;
    const selectedSort = [...view.sortList.querySelectorAll(".sort-option")].find((option) => option.dataset.value === criteria.sort);
    if (selectedSort) view.sortValue.textContent = selectedSort.textContent;
    for (const option of view.sortList.querySelectorAll(".sort-option")) {
      option.setAttribute("aria-selected", String(option === selectedSort));
    }
    view.status.textContent = statusText(session);
    const terminalResults = session.status === "ready" || session.status === "partial";
    view.controls.hidden = !terminalResults;
    view.cancel.hidden = !["validating", "scanning", "normalizing"].includes(session.status);
    view.retry.hidden = !["partial", "failed", "unsupported", "cancelled"].includes(session.status);
    view.continueButton.hidden = session.status !== "partial";
    view.warning.hidden = !session.warning && !session.error;
    view.warning.className = session.error ? "error" : "warning";
    view.warning.textContent = session.error?.message ?? session.warning?.message ?? "";
    const distilleries = [...new Map(session.entries.filter((entry) => entry.distillery).map((entry) => [entry.distillery.toLocaleLowerCase("en-US"), entry.distillery])).entries()].sort((a, b) => a[1].localeCompare(b[1], "en-US"));
    const currentDistillery = criteria.distillery ?? "";
    const distilleryOptions = distilleries.map(([, label], index) => {
      const option = document.createElement("button");
      option.type = "button";
      option.className = "sort-option distillery-option";
      option.id = `wew-distillery-option-${index}`;
      option.dataset.value = label;
      option.setAttribute("role", "option");
      option.setAttribute("aria-selected", String(label.toLocaleLowerCase("en-US") === currentDistillery.toLocaleLowerCase("en-US")));
      option.textContent = label;
      return option;
    });
    view.distilleryList.replaceChildren(...distilleryOptions);
    view.distillery.value = currentDistillery;
    view.distilleryField.hidden = distilleries.length === 0;
    if (!distilleries.length) {
      view.distilleryList.hidden = true;
      view.distillery.setAttribute("aria-expanded", "false");
    }
    const result = selectEntries(session.entries, criteria);
    const fragment = document.createDocumentFragment();
    for (const entry of result.entries) fragment.append(rowFor(entry));
    view.body.replaceChildren(fragment);
    view.count.textContent = terminalResults ? result.total ? `${result.total} of ${session.entries.length} whiskeys shown.` : "No matching whiskeys. Clear search or reset filters." : "";
    const table = view.shadow.querySelector("#wew-table");
    if (table) table.hidden = !terminalResults || result.total === 0;
    view.nameHeader.setAttribute("aria-sort", criteria.sort === "name-asc" ? "ascending" : "none");
    view.priceHeader.setAttribute("aria-sort", criteria.sort === "price-asc" ? "ascending" : criteria.sort === "price-desc" ? "descending" : "none");
  }

  // src/content/bootstrap.ts
  var state = window.__whiskeyEmpireWest ?? { scanner: new Scanner(), panel: null, criteria: resetCriteria(), listenerInstalled: false };
  window.__whiskeyEmpireWest = state;
  function render(session) {
    if (state.panel) updatePanel(state.panel, session, state.criteria);
  }
  function createOrFocusPanel() {
    if (state.panel && document.contains(state.panel.host)) {
      focusPanel(state.panel);
      return state.panel;
    }
    const located = locateActiveList(document);
    const anchor = located.ok ? located.root : document.body.firstElementChild ?? document.body;
    state.panel = createPanel(anchor, {
      onCriteria: (criteria) => {
        state.criteria = criteria;
        render(state.scanner.current);
      },
      onReset: () => {
        state.criteria = resetCriteria();
        if (state.panel) {
          state.panel.query.value = "";
          state.panel.distillery.value = "";
          state.panel.sort.value = "source";
        }
        render(state.scanner.current);
      },
      onCancel: () => state.scanner.cancel(render),
      onRetry: () => {
        state.scanner.reset();
        void start();
      },
      onContinue: () => state.scanner.continuePartial(render),
      onClose: () => {
        state.scanner.cancel();
        state.scanner.reset();
        const fallback = located.ok ? located.root.querySelector("h1,h2,h3,[tabindex]") : null;
        state.panel?.host.remove();
        state.panel = null;
        if (fallback) {
          if (!fallback.hasAttribute("tabindex")) fallback.tabIndex = -1;
          fallback.focus();
        }
      }
    });
    return state.panel;
  }
  async function start() {
    await activateWhiskeyTab(document);
    createOrFocusPanel();
    void state.scanner.start(document, render);
    return { ok: true, snapshot: state.scanner.snapshot() };
  }
  if (!state.listenerInstalled) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (!isExtensionRequest(message)) return false;
      if (message.type === "START_SCAN") void start().then(sendResponse).catch(() => sendResponse({
        ok: false,
        error: { code: "NOT_INJECTED", message: "The explorer could not start. Reload the page and try again." }
      }));
      else if (message.type === "GET_STATUS") sendResponse({ ok: true, snapshot: state.scanner.snapshot() });
      else {
        state.scanner.cancel(render);
        sendResponse({ ok: true, snapshot: state.scanner.snapshot() });
      }
      return message.type === "START_SCAN";
    });
    state.listenerInstalled = true;
  }
  if (document.getElementById(PANEL_HOST_ID)) state.panel?.heading.focus();
})();
