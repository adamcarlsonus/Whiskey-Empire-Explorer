"use strict";
(() => {
  // src/shared/target.ts
  var SUPPORTED_ORIGIN = "https://thewestsideblono.com";
  var SUPPORTED_PATH = "/drink/drink-menu/";
  var SUPPORTED_URL = `${SUPPORTED_ORIGIN}${SUPPORTED_PATH}`;
  var PAGINATION_ORIGIN = "https://business.untappd.com";
  var MAX_PAGES = 20;
  var PAGINATION_PATH = /^\/locations\/\d+\/themes\/\d+\/items\/?$/;
  function canonicalizePaginationUrl(url) {
    if (url.protocol !== "https:" || url.origin !== PAGINATION_ORIGIN || !PAGINATION_PATH.test(url.pathname)) return null;
    const page = url.searchParams.get("page");
    const sectionId = url.searchParams.get("section_id");
    if (!page || !/^\d+$/.test(page) || Number(page) < 1 || Number(page) > MAX_PAGES) return null;
    if (!sectionId || !/^\d+$/.test(sectionId)) return null;
    url.search = "";
    url.searchParams.set("page", page);
    url.searchParams.set("section_id", sectionId);
    return url;
  }
  function canonicalizeUrl(value, base = SUPPORTED_URL) {
    try {
      const url = new URL(value, base);
      url.hash = "";
      if (url.origin === PAGINATION_ORIGIN) return canonicalizePaginationUrl(url);
      if (url.protocol !== "https:" || url.origin !== SUPPORTED_ORIGIN) return null;
      const normalizedPath = url.pathname.endsWith("/") ? url.pathname : `${url.pathname}/`;
      if (normalizedPath !== SUPPORTED_PATH) return null;
      url.pathname = SUPPORTED_PATH;
      return url;
    } catch {
      return null;
    }
  }
  function isSupportedUrl(value) {
    const url = canonicalizeUrl(value);
    if (!url) return false;
    const supplied = new URL(value);
    return supplied.origin === SUPPORTED_ORIGIN && (supplied.pathname === SUPPORTED_PATH || supplied.pathname === SUPPORTED_PATH.slice(0, -1));
  }

  // src/popup/popup.ts
  var scanButton = document.querySelector("#scan");
  var guidance = document.querySelector("#guidance");
  var status = document.querySelector("#status");
  var activeTabId = null;
  var pollId = null;
  function setStatus(message) {
    if (status) status.textContent = message;
  }
  function snapshotText(snapshot) {
    if (snapshot.error) return snapshot.error.message;
    const prefix = snapshot.status === "ready" ? "Complete" : snapshot.status === "partial" ? "Partial" : snapshot.status;
    return `${prefix}: ${snapshot.pagesProcessed}/${snapshot.pagesDiscovered} pages, ${snapshot.entriesCollected} entries.`;
  }
  async function send(message) {
    if (activeTabId === null) return { ok: false, error: { code: "NOT_INJECTED", message: "No active tab is available." } };
    return await new Promise((resolve) => {
      let settled = false;
      const finish = (response) => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timeoutId);
        resolve(response);
      };
      const timeoutId = window.setTimeout(() => finish({
        ok: false,
        error: { code: "NOT_INJECTED", message: "The page did not answer the scan request. Reload the page and try again." }
      }), 1e4);
      void chrome.tabs.sendMessage(activeTabId, message).then(finish).catch(() => finish({ ok: false, error: { code: "NOT_INJECTED", message: "The panel is not available in this tab." } }));
    });
  }
  async function poll() {
    const response = await send({ type: "GET_STATUS" });
    if (response.ok) setStatus(snapshotText(response.snapshot));
  }
  async function initialize() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      activeTabId = tab?.id ?? null;
      const supported = Boolean(tab?.url && isSupportedUrl(tab.url));
      if (scanButton) scanButton.disabled = !supported;
      if (guidance) guidance.textContent = supported ? "Scan will open the Whiskey Empire collection automatically." : "Open the Westside drink menu to use this extension.";
      if (supported) {
        await poll();
        pollId = window.setInterval(() => void poll(), 750);
      }
    } catch {
      if (scanButton) scanButton.disabled = true;
      setStatus("Chrome could not inspect the active tab. Reload the page and reopen this popup.");
    }
  }
  scanButton?.addEventListener("click", async () => {
    if (activeTabId === null) return;
    scanButton.disabled = true;
    setStatus("Opening the explorer\u2026");
    try {
      await chrome.scripting.executeScript({ target: { tabId: activeTabId }, files: ["content.js"] });
      const response = await send({ type: "START_SCAN" });
      setStatus(response.ok ? snapshotText(response.snapshot) : response.error.message);
      if (response.ok && !response.snapshot.error) window.close();
    } catch {
      setStatus("Chrome could not open the explorer on this page. No broader permission was requested.");
    } finally {
      scanButton.disabled = false;
    }
  });
  window.addEventListener("unload", () => {
    if (pollId !== null) window.clearInterval(pollId);
  });
  void initialize();
})();
